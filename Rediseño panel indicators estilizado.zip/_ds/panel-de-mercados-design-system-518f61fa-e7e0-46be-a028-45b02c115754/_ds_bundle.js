/* @ds-bundle: {"format":3,"namespace":"PanelDeMercadosDesignSystem_518f61","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"DeltaBadge","sourcePath":"components/core/DeltaBadge.jsx"},{"name":"ChartPanel","sourcePath":"components/data/ChartPanel.jsx"},{"name":"MetricCard","sourcePath":"components/data/MetricCard.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Button.jsx":"1b6dc2cde3f2","components/core/DeltaBadge.jsx":"9d066bf263af","components/data/ChartPanel.jsx":"ff24b7a27473","components/data/MetricCard.jsx":"a5b0472bdccf","components/forms/Select.jsx":"d9a013052f58","components/navigation/Tabs.jsx":"1b96b2700254","ui_kits/dashboard/data.js":"96be32fcb890","ui_kits/dashboard/screens.jsx":"55d50b3f7fc7"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PanelDeMercadosDesignSystem_518f61 = window.PanelDeMercadosDesignSystem_518f61 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — the panel's action control.
 * Primary variant wears the brand gradient with dark ink; ghost is a
 * transparent outline that warms its border on hover.
 */
function Button({
  variant = "primary",
  size = "md",
  type = "button",
  disabled = false,
  icon = null,
  children,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "6px 12px",
      fontSize: "12px"
    },
    md: {
      padding: "9px 16px",
      fontSize: "13px"
    },
    lg: {
      padding: "12px 22px",
      fontSize: "14px"
    }
  };
  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: "8px",
    border: "none",
    borderRadius: "var(--radius-sm)",
    fontFamily: "var(--font-sans)",
    fontWeight: "var(--fw-bold)",
    lineHeight: 1,
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.5 : 1,
    transition: "var(--t-filter), var(--t-press)",
    ...sizes[size]
  };
  const variants = {
    primary: {
      background: "var(--brand-gradient)",
      color: "var(--text-on-accent)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-primary)",
      border: "var(--border)"
    },
    subtle: {
      background: "var(--surface-input)",
      color: "var(--text-primary)",
      border: "var(--border)"
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    style: {
      ...base,
      ...variants[variant],
      ...style
    },
    onMouseEnter: e => {
      if (!disabled) e.currentTarget.style.filter = "var(--hover-brighten)";
      if (!disabled && variant === "ghost") e.currentTarget.style.borderColor = "var(--orange)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.filter = "none";
      if (variant === "ghost") e.currentTarget.style.borderColor = "var(--border-default)";
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = "var(--press-nudge)";
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = "none";
    }
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      fontSize: "1.05em",
      lineHeight: 0
    }
  }, icon) : null, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/DeltaBadge.jsx
try { (() => {
/**
 * DeltaBadge — the up / down / flat change indicator used on every
 * metric card. Green ▲ for gains, red ▼ for losses, gray ■ when flat.
 * Renders "—" when value is null/undefined (no prior datum).
 */
function DeltaBadge({
  value = null,
  unit = "%",
  decimals,
  style = {}
}) {
  const wrap = {
    display: "inline-flex",
    alignItems: "center",
    gap: "5px",
    fontFamily: "var(--font-sans)",
    fontVariantNumeric: "tabular-nums",
    fontSize: "var(--fs-delta)",
    fontWeight: "var(--fw-bold)",
    whiteSpace: "nowrap",
    ...style
  };
  if (value === null || value === undefined || Number.isNaN(value)) {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        ...wrap,
        color: "var(--status-flat)"
      }
    }, "\u2014");
  }
  const up = value > 0.0005;
  const down = value < -0.0005;
  const color = up ? "var(--status-up)" : down ? "var(--status-down)" : "var(--status-flat)";
  const arrow = up ? "▲" : down ? "▼" : "■";
  const dec = decimals ?? (unit === "pp" ? 1 : 2);
  const sign = value > 0 ? "+" : "";
  const txt = `${sign}${value.toFixed(dec)}${unit === "pp" ? " pp" : unit}`;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      ...wrap,
      color
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, arrow), txt);
}
Object.assign(__ds_scope, { DeltaBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/DeltaBadge.jsx", error: String((e && e.message) || e) }); }

// components/data/ChartPanel.jsx
try { (() => {
/**
 * ChartPanel — the carbon container that frames a chart in the panel.
 * A title, an optional controls row (e.g. a Select), and the plotting
 * area ("lienzo"). Set `wide` to span the full grid width.
 */
function ChartPanel({
  title,
  controls = null,
  tall = false,
  wide = false,
  children,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "var(--border)",
      borderRadius: "var(--radius-md)",
      padding: "16px 16px 10px",
      boxShadow: "var(--shadow-card)",
      fontFamily: "var(--font-sans)",
      gridColumn: wide ? "1 / -1" : "auto",
      ...style
    }
  }, title ? /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: "0 0 10px",
      fontSize: "var(--fs-h3)",
      fontWeight: "var(--fw-bold)",
      color: "var(--text-primary)"
    }
  }, title) : null, controls ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: "10px"
    }
  }, controls) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: tall ? "320px" : "260px"
    }
  }, children));
}
Object.assign(__ds_scope, { ChartPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ChartPanel.jsx", error: String((e && e.message) || e) }); }

// components/data/MetricCard.jsx
try { (() => {
/**
 * MetricCard — the panel's core data tile. Carbon surface with the
 * signature 3px gradient bar down the left edge: muted series name,
 * a large gold value, a delta badge and a date stamp. Optional
 * italic interpretive line (used on FX cards).
 */
function MetricCard({
  name,
  value,
  delta = null,
  deltaUnit = "%",
  interp = null,
  date = null,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      overflow: "hidden",
      background: "var(--surface-card)",
      border: "var(--border)",
      borderRadius: "var(--radius-md)",
      padding: "14px 16px",
      boxShadow: "var(--shadow-card)",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      bottom: 0,
      width: "var(--accent-rule)",
      background: "var(--brand-gradient)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-name)",
      color: "var(--text-secondary)",
      fontWeight: "var(--fw-medium)",
      minHeight: "30px"
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-value)",
      fontWeight: "var(--fw-bold)",
      color: "var(--text-value)",
      marginTop: "4px",
      fontVariantNumeric: "tabular-nums"
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "3px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.DeltaBadge, {
    value: delta,
    unit: deltaUnit
  })), interp ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-fine)",
      color: "var(--text-secondary)",
      fontStyle: "italic",
      marginTop: "3px"
    }
  }, interp) : null, date ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-fine2)",
      color: "var(--text-secondary)",
      marginTop: "3px",
      fontVariantNumeric: "tabular-nums"
    }
  }, date) : null);
}
Object.assign(__ds_scope, { MetricCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/MetricCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
/**
 * Select — the panel's dropdown control, used to switch the FX series
 * shown in a chart. Raised neutral surface, hairline border, 7px radius.
 * Optional leading label sits inline to the left.
 */
function Select({
  label = null,
  value,
  onChange = () => {},
  options = [],
  hint = null,
  style = {}
}) {
  const control = /*#__PURE__*/React.createElement("select", {
    value: value,
    onChange: e => onChange(e.target.value),
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--fs-tab)",
      padding: "6px 10px",
      borderRadius: "var(--radius-sm)",
      border: "var(--border)",
      background: "var(--surface-input)",
      color: "var(--text-primary)",
      cursor: "pointer",
      ...style
    }
  }, options.map(o => {
    const v = typeof o === "string" ? o : o.value;
    const l = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  }));
  if (!label && !hint) return control;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
      fontFamily: "var(--font-sans)"
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: "var(--fs-meta)",
      color: "var(--text-secondary)",
      fontWeight: "var(--fw-medium)"
    }
  }, label) : null, control, hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--fs-name)",
      color: "var(--text-secondary)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
/**
 * Tabs — the panel's primary section navigation. A scrollable row of
 * text buttons; the active tab carries the brand gradient as a 3px
 * bottom rule and brightens its label to full ink.
 */
function Tabs({
  tabs = [],
  value,
  onChange = () => {},
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    role: "tablist",
    style: {
      display: "flex",
      gap: "4px",
      background: "var(--surface-header)",
      padding: "0 18px",
      borderBottom: "var(--border)",
      overflowX: "auto",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, tabs.map(t => {
    const id = typeof t === "string" ? t : t.id;
    const label = typeof t === "string" ? t : t.label;
    const active = id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: id,
      role: "tab",
      "aria-selected": active,
      onClick: () => onChange(id),
      style: {
        background: "none",
        border: "none",
        cursor: "pointer",
        fontSize: "var(--fs-tab)",
        fontWeight: "var(--fw-bold)",
        padding: "14px 18px",
        whiteSpace: "nowrap",
        color: active ? "var(--text-primary)" : "var(--text-secondary)",
        borderBottom: "var(--accent-rule) solid transparent",
        borderImage: active ? "var(--brand-gradient) 1" : "none",
        transition: "var(--t-color)"
      },
      onMouseEnter: e => {
        if (!active) e.currentTarget.style.color = "var(--text-primary)";
      },
      onMouseLeave: e => {
        if (!active) e.currentTarget.style.color = "var(--text-secondary)";
      }
    }, label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/data.js
try { (() => {
/* Sample market data for the Panel de mercados UI kit.
   Plausible 2021→2026 monthly series, generated procedurally so the file
   stays small. Values are illustrative, not live. */
(function () {
  // deterministic pseudo-random walk
  function walk(start, n, vol, drift, lo, hi) {
    const out = [];
    let v = start;
    let seed = start * 1000 + n;
    const rnd = () => {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };
    for (let i = 0; i < n; i++) {
      v = v + (rnd() - 0.5) * vol + drift;
      if (lo != null) v = Math.max(lo, v);
      if (hi != null) v = Math.min(hi, v);
      out.push(Math.round(v * 10000) / 10000);
    }
    return out;
  }

  // monthly labels Jan-2021 .. Jun-2026 (66 points)
  const fechas = [];
  for (let y = 2021; y <= 2026; y++) {
    for (let m = 1; m <= 12; m++) {
      if (y === 2026 && m > 6) break;
      fechas.push(`${y}-${String(m).padStart(2, "0")}-01`);
    }
  }
  const N = fechas.length;
  const series = {
    "MXN por USD": walk(20.5, N, 0.6, -0.03, 16.5, 21),
    "EUR por USD": walk(0.84, N, 0.012, 0.0008, 0.80, 0.96),
    "JPY por USD": walk(104, N, 3.2, 0.85, 102, 162),
    "GBP por USD": walk(0.73, N, 0.011, 0.0006, 0.71, 0.84),
    "CNY por USD": walk(6.45, N, 0.07, 0.012, 6.3, 7.35),
    "CAD por USD": walk(1.27, N, 0.02, 0.0009, 1.20, 1.45),
    "Henry Hub ($/MMBtu)": walk(2.6, N, 0.55, 0.005, 1.6, 9.5),
    "WTI ($/bbl)": walk(52, N, 6, 0.35, 36, 120),
    "Brent ($/bbl)": walk(55, N, 6, 0.38, 40, 124),
    "S&P 500": walk(3800, N, 130, 28, 3200, 6200)
  };
  const monedas = ["MXN por USD", "EUR por USD", "JPY por USD", "GBP por USD", "CNY por USD", "CAD por USD"];
  const ISO_NOMBRE = {
    "MXN por USD": "el peso",
    "EUR por USD": "el euro",
    "JPY por USD": "el yen",
    "GBP por USD": "la libra",
    "CNY por USD": "el yuan",
    "CAD por USD": "el dólar canadiense"
  };

  // last two non-null → pct change
  function pct(arr) {
    const v = arr.slice(-2);
    if (v.length < 2 || !v[1]) return null;
    return (v[0] - v[1]) / v[1] * 100;
  }
  function fmt(name, val) {
    if (name === "JPY por USD") return val.toFixed(2);
    if (name.indexOf("por USD") > -1) return val.toFixed(4);
    return val.toLocaleString("es-MX", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }
  function resumen(names) {
    return names.map(name => {
      const arr = series[name];
      const val = arr[arr.length - 1];
      const c = pct(arr);
      let interp = null;
      if (ISO_NOMBRE[name]) {
        const nm = ISO_NOMBRE[name].charAt(0).toUpperCase() + ISO_NOMBRE[name].slice(1);
        interp = c == null ? null : c < -0.0005 ? nm + " se fortaleció" : c > 0.0005 ? nm + " se debilitó" : nm + " sin cambio";
      }
      return {
        serie: name,
        valor: fmt(name, val),
        delta: c,
        interp,
        fecha: fechas[fechas.length - 1]
      };
    });
  }
  const macro = [{
    nombre: "Inflación YoY (CPI)",
    valores: walk(1.4, N, 0.3, 0.04, 0.5, 9.1),
    fecha: fechas
  }, {
    nombre: "Desempleo",
    valores: walk(6.7, N, 0.18, -0.04, 3.4, 6.9),
    fecha: fechas
  }, {
    nombre: "PIB real (crec. anualizado)",
    valores: walk(3.1, N, 0.9, -0.01, -1.5, 6.5),
    fecha: fechas
  }];
  window.PANEL_DATA = {
    fechas,
    series,
    monedas,
    ISO_NOMBRE,
    divisas: resumen(monedas),
    commodities: resumen(["Henry Hub ($/MMBtu)", "WTI ($/bbl)", "Brent ($/bbl)", "S&P 500"]),
    macro,
    pct
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/data.js", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/screens.jsx
try { (() => {
/* Panel de mercados — UI kit screens.
   Composes the design-system components; charts via Chart.js. */
const {
  MetricCard,
  ChartPanel,
  Tabs,
  Select,
  Button
} = window.PanelDeMercadosDesignSystem_518f61;
const D = window.PANEL_DATA;
const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim();

// shared Chart.js options matching the live panel
function baseOpts(extra) {
  const gris = "#9aa0a6",
    linea = "#3a3a42";
  return Object.assign({
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: "index",
      intersect: false
    },
    plugins: {
      legend: {
        display: false,
        labels: {
          color: "#cfcfcf",
          boxWidth: 12,
          font: {
            size: 11
          }
        }
      }
    },
    elements: {
      point: {
        radius: 0
      },
      line: {
        borderWidth: 1.8,
        tension: 0.12
      }
    },
    scales: {
      x: {
        ticks: {
          maxTicksLimit: 7,
          font: {
            size: 11
          },
          color: gris,
          maxRotation: 0
        },
        grid: {
          display: false
        },
        border: {
          color: linea
        }
      },
      y: {
        ticks: {
          font: {
            size: 11
          },
          color: gris
        },
        grid: {
          color: "rgba(255,255,255,.06)"
        },
        border: {
          color: linea
        }
      }
    }
  }, extra || {});
}

// React wrapper around a Chart.js line chart
function LineChart({
  labels,
  datasets,
  opts
}) {
  const ref = React.useRef(null);
  const chart = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current) return;
    chart.current = new Chart(ref.current, {
      type: "line",
      data: {
        labels,
        datasets: datasets.map(d => Object.assign({
          spanGaps: true
        }, d))
      },
      options: baseOpts(opts)
    });
    return () => chart.current && chart.current.destroy();
  }, []);
  React.useEffect(() => {
    if (!chart.current) return;
    chart.current.data.labels = labels;
    chart.current.data.datasets = datasets.map(d => Object.assign({
      spanGaps: true
    }, d));
    chart.current.update();
  }, [datasets]);
  return /*#__PURE__*/React.createElement("canvas", {
    ref: ref
  });
}
function CardGrid({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "12px",
      gridTemplateColumns: "repeat(auto-fill, minmax(170px, 1fr))"
    }
  }, children);
}
function Eyebrow({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-label)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-eyebrow)",
      color: "var(--text-secondary)",
      fontWeight: "var(--fw-bold)",
      margin: "24px 4px 12px"
    }
  }, children);
}

/* ---------------- Divisas ---------------- */
function DivisasScreen() {
  const [cur, setCur] = React.useState("MXN por USD");
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Tipos de cambio \u2014 \xFAltimos valores"), /*#__PURE__*/React.createElement(CardGrid, null, D.divisas.map(r => /*#__PURE__*/React.createElement(MetricCard, {
    key: r.serie,
    name: r.serie,
    value: r.valor,
    delta: r.delta,
    interp: r.interp,
    date: r.fecha
  }))), /*#__PURE__*/React.createElement(Eyebrow, null, "Evoluci\xF3n"), /*#__PURE__*/React.createElement(ChartPanel, {
    wide: true,
    tall: true,
    controls: /*#__PURE__*/React.createElement(Select, {
      label: "Divisa:",
      value: cur,
      onChange: setCur,
      options: D.monedas,
      hint: "unidades por 1 USD"
    })
  }, /*#__PURE__*/React.createElement(LineChart, {
    labels: D.fechas,
    datasets: [{
      data: D.series[cur],
      borderColor: css("--orange")
    }]
  })));
}

/* ---------------- Commodities ---------------- */
function CommoditiesScreen() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Commodities y mercado \u2014 \xFAltimos valores"), /*#__PURE__*/React.createElement(CardGrid, null, D.commodities.map(r => /*#__PURE__*/React.createElement(MetricCard, {
    key: r.serie,
    name: r.serie,
    value: r.valor,
    delta: r.delta,
    date: r.fecha
  }))), /*#__PURE__*/React.createElement(Eyebrow, null, "Evoluci\xF3n"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "16px",
      gridTemplateColumns: "repeat(2, 1fr)"
    }
  }, /*#__PURE__*/React.createElement(ChartPanel, {
    title: "Henry Hub \u2014 gas natural ($/MMBtu)"
  }, /*#__PURE__*/React.createElement(LineChart, {
    labels: D.fechas,
    datasets: [{
      data: D.series["Henry Hub ($/MMBtu)"],
      borderColor: css("--gold")
    }]
  })), /*#__PURE__*/React.createElement(ChartPanel, {
    title: "Petr\xF3leo \u2014 WTI vs. Brent ($/bbl)"
  }, /*#__PURE__*/React.createElement(LineChart, {
    labels: D.fechas,
    opts: {
      plugins: {
        legend: {
          display: true,
          labels: {
            boxWidth: 12,
            font: {
              size: 11
            },
            color: "#cfcfcf"
          }
        }
      }
    },
    datasets: [{
      data: D.series["WTI ($/bbl)"],
      borderColor: css("--orange"),
      label: "WTI"
    }, {
      data: D.series["Brent ($/bbl)"],
      borderColor: css("--red"),
      label: "Brent"
    }]
  })), /*#__PURE__*/React.createElement(ChartPanel, {
    title: "S&P 500",
    wide: true
  }, /*#__PURE__*/React.createElement(LineChart, {
    labels: D.fechas,
    datasets: [{
      data: D.series["S&P 500"],
      borderColor: css("--silver")
    }]
  }))));
}

/* ---------------- Macro ---------------- */
function MacroScreen() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Macro EE. UU. \u2014 \xFAltimos valores"), /*#__PURE__*/React.createElement(CardGrid, null, D.macro.map(ind => {
    const v = ind.valores.slice(-2);
    const val = v[v.length - 1];
    const delta = v.length >= 2 ? v[1] - v[0] : null;
    return /*#__PURE__*/React.createElement(MetricCard, {
      key: ind.nombre,
      name: ind.nombre,
      value: val.toFixed(1) + "%",
      delta: delta == null ? null : val - v[0],
      deltaUnit: "pp",
      date: ind.fecha[ind.fecha.length - 1]
    });
  })), /*#__PURE__*/React.createElement(Eyebrow, null, "Evoluci\xF3n"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "16px",
      gridTemplateColumns: "1fr"
    }
  }, D.macro.map(ind => /*#__PURE__*/React.createElement(ChartPanel, {
    key: ind.nombre,
    title: ind.nombre + " (%)",
    wide: true
  }, /*#__PURE__*/React.createElement(LineChart, {
    labels: ind.fecha,
    datasets: [{
      data: ind.valores,
      borderColor: "#FF9D2E"
    }],
    opts: {
      plugins: {
        legend: {
          display: false
        }
      }
    }
  })))));
}

/* ---------------- Archivos ---------------- */
function ArchivosScreen() {
  const file = (title, desc, btn) => /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-card)",
      border: "var(--border)",
      borderRadius: "var(--radius-md)",
      padding: "18px"
    }
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: "0 0 6px",
      fontSize: "15px",
      color: "var(--text-primary)"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 14px",
      fontSize: "13px",
      color: "var(--text-secondary)",
      lineHeight: 1.45
    }
  }, desc), btn);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Descargas"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "14px",
      gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))"
    }
  }, file("Excel completo", "Todas las series con formato: resumen, datos diarios, inflación y gráficas por divisa.", /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "\u2B07"
  }, "Descargar .xlsx")), file("Panel general (imagen)", "Henry Hub, petróleo, S&P 500 e inflación en una sola imagen.", /*#__PURE__*/React.createElement(Button, {
    variant: "ghost"
  }, "Ver PNG")), file("Divisas (imagen)", "Las 10 divisas frente al dólar en un panel de imagen.", /*#__PURE__*/React.createElement(Button, {
    variant: "ghost"
  }, "Ver PNG"))));
}

/* ---------------- Header + App ---------------- */
function Header() {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      background: "linear-gradient(120deg, #FFC400, #FF7A18, #E62315) bottom / 100% 3px no-repeat, var(--surface-header)",
      padding: "20px 26px 16px",
      boxShadow: "var(--shadow-header)"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "0 0 4px",
      fontSize: "var(--fs-display)",
      fontWeight: "var(--fw-black)",
      letterSpacing: ".2px",
      background: "var(--brand-gradient)",
      WebkitBackgroundClip: "text",
      backgroundClip: "text",
      WebkitTextFillColor: "transparent",
      display: "inline-block"
    }
  }, "Panel de mercados"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--fs-meta)",
      color: "var(--text-secondary)"
    }
  }, "Actualizado: 17 jun 2026, 16:00 (tu hora) \xB7 hace un momento \xB7 Cambio vs. dato previo"));
}
const TABS = [{
  id: "divisas",
  label: "Divisas"
}, {
  id: "commodities",
  label: "Commodities"
}, {
  id: "macro",
  label: "Macro EE. UU."
}, {
  id: "archivos",
  label: "Archivos"
}];
function App() {
  const [tab, setTab] = React.useState("divisas");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      background: "var(--bg-app)",
      color: "var(--text-primary)",
      fontFamily: "var(--font-sans)",
      lineHeight: "var(--lh-base)"
    }
  }, /*#__PURE__*/React.createElement(Header, null), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    tabs: TABS
  })), /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: "var(--content-max)",
      margin: "0 auto",
      padding: "22px 20px 60px"
    }
  }, tab === "divisas" && /*#__PURE__*/React.createElement(DivisasScreen, null), tab === "commodities" && /*#__PURE__*/React.createElement(CommoditiesScreen, null), tab === "macro" && /*#__PURE__*/React.createElement(MacroScreen, null), tab === "archivos" && /*#__PURE__*/React.createElement(ArchivosScreen, null)), /*#__PURE__*/React.createElement("footer", {
    style: {
      maxWidth: "var(--content-max)",
      margin: "0 auto",
      padding: "8px 20px 40px",
      color: "var(--text-secondary)",
      fontSize: "12px"
    }
  }, "Fuentes \u2014 Henry Hub: EIA \xB7 S&P 500, WTI, Brent, inflaci\xF3n, desempleo, PIB: FRED \xB7 Divisas: Frankfurter (BCE). Datos ilustrativos para la maqueta."));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.DeltaBadge = __ds_scope.DeltaBadge;

__ds_ns.ChartPanel = __ds_scope.ChartPanel;

__ds_ns.MetricCard = __ds_scope.MetricCard;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
