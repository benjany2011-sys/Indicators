# Panel de mercados — Design System

A design system for **Panel de mercados** ("Markets Panel") — a Spanish-language
financial dashboard that tracks foreign-exchange rates, energy & equity
commodities, and U.S. macro indicators. The product is a single auto-updating
web panel (plus an Excel/PNG export pipeline) that pulls daily data from public
sources and presents it as metric cards and time-series charts.

The defining visual idea is a **dark "carbón" (charcoal) interface lit by a warm
gold → orange → red gradient**, used for the wordmark, active states, primary
buttons, and a 3px accent rule down the left of every metric card.

> **Audience & language:** the entire product is written in **Mexican Spanish
> (es-MX)**. Numbers are localized (`18,42`), currencies are framed as "unidades
> por 1 USD", and macro figures use percentage points.

---

## Sources

This system was reverse-engineered from the product's own code. Explore these to
build richer, more faithful designs:

- **GitHub — `benjany2011-sys/Indicators`**
  <https://github.com/benjany2011-sys/Indicators>
  - `index.html` — the live web panel (the canonical source of all visual tokens,
    component styling, tabs, cards, and Chart.js configuration).
  - `actualizar_datos.py` — the Python ETL that builds the data: series names,
    formats, number rounding, source attributions, and the Excel color palette
    (which mirrors the web panel).
  - `resultados/` — generated artifacts (`datos.json`, matplotlib PNG panels,
    Excel workbooks).

Data sources behind the product: **EIA** (Henry Hub gas), **FRED** (S&P 500, WTI,
Brent, CPI/inflation, unemployment, GDP), **Frankfurter / ECB** (FX rates).

---

## CONTENT FUNDAMENTALS

**Language.** Mexican Spanish throughout. Section labels, tabs, and copy are all
Spanish: *Divisas, Commodities, Macro EE. UU., Archivos, Evolución, Descargas,
últimos valores*.

**Voice.** Third-person, factual, neutral-analyst. The product narrates the
market, never the user — there is no "tú/usted" address in the data UI. The only
second-person voice appears in operational/error notices ("Verifica también
que…", "tu hora local").

**Tone.** Precise and restrained. Copy explains *what a number means* in plain
terms rather than hyping it. Interpretive lines are short and declarative:
- "El peso se fortaleció" / "El euro se debilitó" / "El yen sin cambio"
- Footnote: "El % junto a cada cifra compara el último dato con el anterior
  disponible; las fechas pueden diferir según el rezago de cada fuente."

**Casing.** Sentence case for headings and copy. Section eyebrows are the one
exception — UPPERCASE with letter-spacing ("TIPOS DE CAMBIO — ÚLTIMOS VALORES").
Tabs are Title Case. Currency codes are uppercase ISO ("MXN por USD").

**Numbers.** Localized with `toLocaleString("es-MX")`. Prices to 2 decimals, FX
to 4 (or 2 for JPY/KRW/INR), percentages to 1 decimal. Deltas always carry a sign
and an arrow: `▲ +1.24%`, `▼ -0.60%`, `■ —`. Macro changes are in **pp**
(percentage points), price/FX changes in **%**.

**Units are explicit.** "unidades por 1 USD", "$/MMBtu", "$/bbl" — the unit is
always stated next to or under the number. Sources are always credited in the
footer.

**No emoji.** The product uses **unicode glyphs as functional icons** only
(▲ ▼ ■ ⬇), never decorative emoji.

---

## VISUAL FOUNDATIONS

**Color.** A dark neutral base — app `#1f1f23`, header `#26262b`, cards/panels
`#2a2a30`, inputs `#32323a`, hairlines `#3a3a42`. Text is near-white `#ECECEC`
with `#9aa0a6` gray for secondary. The signature is the warm
**gradient `linear-gradient(120deg, #FFC400, #FF7A18, #E62315)`** (gold→orange
→red). Headline values are rendered in solid **gold `#FFC400`**. Market direction
is a semaphore: green `#37d67a` up, red `#ff5b5b` down, gray flat. **Silver
`#B8BCC0`** is the neutral data-line color (e.g. the S&P series).

**Type.** The native system UI stack
(`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, …`) — no webfont ships.
The wordmark is 23px / 800 with the gradient clipped into the text. Headline
values are 22px / 700 in gold. Section eyebrows are 13px / 700 uppercase with
0.8px tracking. Body is 14px / 1.45. All market numbers use **tabular figures**
so columns align.

**Spacing & layout.** A compact 4px rhythm. Content is centered in a **1180px**
column. Metric cards sit in an auto-fill grid (`minmax(170px, 1fr)`, 12px gap);
charts in a 2-column grid (16px gap) with "wide" panels spanning both columns.
Header padding is `20px 26px 16px`.

**Backgrounds.** Flat dark fills only — **no imagery, no photography, no
patterns or textures.** The gradient is the only "color event," and it appears as
thin accents (3px rules, button fills, clipped wordmark text), never as a
full-bleed background wash.

**Corners & cards.** Cards and panels use a 10px radius; buttons, inputs and
selects use 7px. A card is a `#2a2a30` surface with a 1px `#3a3a42` border, a
subtle dark drop shadow, and a **3px gradient bar down its left edge** (its
single most recognizable trait).

**Borders & shadows.** Hairline 1px borders everywhere. Shadows are near-black
and low-spread (depth in a dark UI comes from shadow, not light):
`0 1px 3px rgba(0,0,0,.25)` for cards, `0 2px 10px rgba(0,0,0,.35)` for the sticky
header. No glows, no colored shadows, no inner shadows.

**Active states.** The active tab and the header bottom-edge use the gradient via
`border-image` as a 3px rule. The active tab label brightens from gray to full
ink.

**Hover.** Primary (gradient) controls **brighten** (`filter: brightness(1.08)`).
Ghost controls **warm their border to orange**. Tab labels **shift gray→ink**.

**Press.** Primary buttons **nudge down 1px** (`translateY(1px)`) — they never
scale up.

**Motion.** Quick and functional only: `color .15s`, `filter .15s`,
`transform .05s`. No bounces, no decorative or looping animation, no entrance
choreography. Chart updates use Chart.js's default transition.

**Transparency & blur.** Essentially none — the UI is opaque. The only
translucency is the faint white grid line inside charts (`rgba(255,255,255,.06)`).

**Charts.** Chart.js line charts: 1.8px strokes, `tension .12`, **no point
markers**, gray axis ticks, faint horizontal grid, no vertical grid. Series use
brand colors — gold (Henry Hub), orange (WTI / single FX), red (Brent), silver
(S&P), a lighter orange `#FF9D2E` for macro. A dashed silver line marks moving
averages.

---

## ICONOGRAPHY

The product has **no icon library and no logo image.** Its iconography is
deliberately minimal and typographic:

- **Unicode glyphs as functional icons:** `▲` (up), `▼` (down), `■` (flat),
  `⬇` (download). These appear inside delta badges and the primary download
  button. Use these exact glyphs — do not substitute an SVG icon set.
- **The wordmark is type, not a mark:** "Panel de mercados" set in the system
  font at 800 weight with the brand gradient clipped into the letterforms. There
  is no logomark or favicon asset in the repo.
- **No emoji**, no PNG/SVG icon sprites, no icon font.

If a future surface genuinely needs a small icon set (settings gear, calendar,
etc.), use a thin **stroke** set that matches the restrained tone (e.g. Lucide at
1.5–2px) and keep it `--gray` by default, warming to the gradient/orange only on
active state. **Flag any such addition as a substitution** — it is not part of
the existing product.

> No font files or logo/illustration assets were available to copy in (the
> product ships only system fonts and type-based branding). If you have brand
> font files or a logomark, share them and they'll be wired in.

---

## INDEX

**Foundations**
- `styles.css` — global entry point (links everything below). Consumers link this.
- `tokens/colors.css` — brand ramp, gradient, carbon surfaces, text, direction.
- `tokens/typography.css` — families, sizes, weights, tabular-figure helper.
- `tokens/spacing.css` — 4px scale, layout widths, radii, accent rule.
- `tokens/effects.css` — shadows, borders, transitions, hover/press conventions.
- `guidelines/*.card.html` — foundation specimen cards (Colors, Type, Spacing).

**Components** (`window.PanelDeMercadosDesignSystem_518f61.*`)
- `components/core/Button.jsx` — primary (gradient) / ghost / subtle action.
- `components/core/DeltaBadge.jsx` — ▲▼■ up/down/flat change indicator.
- `components/data/MetricCard.jsx` — core data tile with gradient accent rule.
- `components/data/ChartPanel.jsx` — carbon container framing a chart.
- `components/forms/Select.jsx` — dropdown with inline label + hint.
- `components/navigation/Tabs.jsx` — section nav with gradient active rule.

**UI kit**
- `ui_kits/dashboard/` — interactive recreation of the full markets panel
  (Divisas, Commodities, Macro EE. UU., Archivos tabs with live Chart.js charts).
  `data.js` holds illustrative sample series; `screens.jsx` composes the system
  components.

**Other**
- `SKILL.md` — packaged skill manifest for use in Claude Code.
